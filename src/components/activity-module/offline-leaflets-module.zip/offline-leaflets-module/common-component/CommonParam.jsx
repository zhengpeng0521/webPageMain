export function basePxFunction() {
	let pxArr = [];
	let basePx = 12;
	for(basePx; basePx <= 200; basePx+=2) {		
		pxArr.push(basePx + 'px');
	}
	return pxArr;
}