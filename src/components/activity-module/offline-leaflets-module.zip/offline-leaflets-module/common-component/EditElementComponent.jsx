import React, {PropTypes} from 'react';
import styles from './EditElementComponent.less';
import ColorSelect from '../../../common/color-select/ColorSelect';
import { Collapse, Slider, InputNumber, Row, Col, Select, Input, Checkbox, Icon, message} from 'antd';
import ImageBarUpdate from '../../module-building/module-toolbar/imageComponent/ImageBarUpdate';
import {basePxFunction} from './CommonParam.jsx';
import ImageComponent from './ImageComponent';

const Panel = Collapse.Panel;
const Option = Select.Option;
const { TextArea } = Input;

function TextComponent({
	
	attrAllConfig,
	attrSelectElement,
	attrAligntext,
	attrElementLocation,
	funcChangeSelectElement,
	funcChangeAligntext,
	funcChangeElementLocation,
	
}) {
						 		
//	let styleText = [{key : '正常', value : 'normal'}, 
//					 {key : '倾斜', value : 'oblique'},
//					 {key : '删除线', value : 'line-through'}, 
//					 {key : '下划线', value : 'underline'},
//					 {key : '加粗', value : 'bold'}];

	let fontFamily = [
		{key : '微软雅黑', value : 'Microsoft YaHei'},
	  	{key : '华文宋体', value : 'STSong'},
	  	{key : '华文楷体', value : 'STKaiti'},
	  	{key : '华文黑体', value : 'STHeiti'},
	  	{key : '新宋体', value : 'NSimSun'},
	  	{key : '宋体', value : 'SimSun'},
	  	{key : '仿宋', value : 'FangSong'},
	  	{key : '黑体', value : 'SimHei'},
	  	{key : '楷体', value : 'KaiTi'},
		{key : '草书', value : 'cursive'},
		{key : '等宽', value : 'monospace'},
		{key : '幻想', value : 'fantasy'},
		{key : '无衬线', value : 'sans-serif'},
		{key : '衬线', value : 'serif'},
		{key : '象形', value : 'pictograph'},	
	];
		
	let behindOrFront = attrAllConfig.mainConfig.attrFrontAndBehind;
	
	let selectTextAlginArr = attrSelectElement&&attrSelectElement.item.selectTextAlign&&attrSelectElement.item.selectTextAlign.split(',') || ["false", "false", "false", "false", "false", "false", "false", "false", "false"];
		
	function generalValue(value) {
					
		if(behindOrFront === 'front') {
			attrAllConfig.frontPageConfig.itemConfig[attrSelectElement.index] = value;
		} else {
			attrAllConfig.behindPageConfig.itemConfig[attrSelectElement.index] = value;
		}		
		funcChangeSelectElement(attrAllConfig);
	}

	function baseOpacityParamonChange(value) {
		attrSelectElement.item.opacity = value;
		generalValue(attrSelectElement);
	}
	
	function baseRotateParamonChange(value) {
		attrSelectElement.item.rotate = value;
		generalValue(attrSelectElement);
	}
	
	function baseBoxShadowParamonChange(value) {
		attrSelectElement.item.boxShadow = value;
		generalValue(attrSelectElement);
	}
	
	function baseBorderWidthParamonChange(value) {
		attrSelectElement.item.borderWidth = value;
		generalValue(attrSelectElement);
	}
	
	function baseBorderRadiusParamonChange(value) {
		attrSelectElement.item.borderRadius = value;
		generalValue(attrSelectElement);
	}
	
	function baseBorderColorParamonChange(value) {
		attrSelectElement.item.borderColor = value;
		generalValue(attrSelectElement);
	}
	
	function baseBorderStyleParamonChange(value) {
		attrSelectElement.item.borderStyle = value;
		generalValue(attrSelectElement);
	}
	
	function basePaddingTopSpacingParamonChange(value) {
		attrSelectElement.item.paddingTop = value;
		generalValue(attrSelectElement);
	}
		
	function basePaddingLeftSpacingParamonChange(value) {
		attrSelectElement.item.paddingLeft = value;
		generalValue(attrSelectElement);
	}
		
	function basePaddingRightSpacingParamonChange(value) {
		attrSelectElement.item.paddingRight = value;
		generalValue(attrSelectElement);
	}
		
	function basePaddingBottomSpacingParamonChange(value) {
		attrSelectElement.item.paddingBottom = value;
		generalValue(attrSelectElement);
	}
	
	var elementH = parseInt(attrSelectElement.item.h&&attrSelectElement.item.h.replace("px", ""));
	
	var elementW = parseInt(attrSelectElement.item.w&&attrSelectElement.item.w.replace("px", ""));
	
	var elementFontSize = parseInt(attrSelectElement.item.h&&attrSelectElement.item.fontSize.replace("px", ""));
		
	function alignParmaChange(value) {

		var totalWidth	= 0;
		var totalHeight = 0;
				
		if(attrAllConfig.mainConfig.attrDirection === 'vertical') {
			totalWidth 	= 583;
			totalHeight = 786;
		} else {
			totalWidth	= 786;
			totalHeight = 583;
		}		
		
		function changeStatus(indexArr, value) {
			indexArr.map((item, index) => {
				if(value == item) {
					attrElementLocation[item].selectStatus = true;
				} else {	
					attrElementLocation[item].selectStatus = false;
				}
			})
		}
		
		if(value <= 2) {
		   	changeStatus([0,1,2], value);
		} else if(value <= 5 && value >= 3) {
			changeStatus([3,4,5], value);
		} 
		
		switch(value) {
			case 0 :
				attrSelectElement.item.y = 0;
				break;
			case 1 :
				attrSelectElement.item.y = totalHeight / 2 - elementH / 2;
				break;
			case 2 :
				attrSelectElement.item.y = totalHeight - elementH - 14;
				break;
			case 3 :
				attrSelectElement.item.x = 0;
				break;
			case 4 :
				attrSelectElement.item.x = totalWidth / 2 - elementW / 2;
				break;
			case 5 :
				attrSelectElement.item.x = totalWidth - elementW - 14;
				break;
			default :
				break;
		}
		
		let elementLocationStatusArr = [];
		attrElementLocation&&attrElementLocation.map((item, index) => {
			if(item.selectStatus) {
				elementLocationStatusArr.push(index);
			}
		})
		attrSelectElement.item.selectElementStatus = elementLocationStatusArr.join(',');
		funcChangeElementLocation(attrElementLocation);
		generalValue(attrSelectElement);
	}

	function baseWidthParamonChange(value) {
		attrSelectElement.item.w = value + 'px';
		generalValue(attrSelectElement);
	}
	
	function baseHeightParamonChange(value) {
		attrSelectElement.item.h = value + 'px';
		generalValue(attrSelectElement);
	}
	
	function baseTopOrBottomParamonChange(value) {
		attrSelectElement.item.y = value;
		generalValue(attrSelectElement);
	}
	
	function baseLeftOrRightParamonChange(value) {
		attrSelectElement.item.x = value;
		generalValue(attrSelectElement);
	}
	
	function baseTextSpacingParamonChange(value) {
		attrSelectElement.item.letterSpacing = value;
		generalValue(attrSelectElement);
	}
	
	function baseBackgroundColorParamonChange(value) {
		attrSelectElement.item.backgroundColor = value;
		generalValue(attrSelectElement);
	}
	
	function baseBackgroundImageParamonChange(value) {
		attrSelectElement.item.backgroundImage = value;
		generalValue(attrSelectElement);
	}
	
	function baseTextColorParamonChange(value) {
		attrSelectElement.item.color = value;
		generalValue(attrSelectElement);
	}
	
	function baseTextPxParamonChange(value) {
		attrSelectElement.item.fontSize = value;
		generalValue(attrSelectElement);
	}
	
	function baseTextParamonChange(value) {		
		if(value.target.value.length > attrSelectElement.item.textMaxLength && attrSelectElement.item.orgSet) {
		   return message.error(`最多输入${attrSelectElement.item.textMaxLength}个字`, 1);
		} else {
			attrSelectElement.item.value = value.target.value;
			generalValue(attrSelectElement);
		}
	}
	
	function baseOrgSetParamonChange(value) {
		attrSelectElement.item.orgSet = value.target.checked;
		generalValue(attrSelectElement);
	}
	
	function textAlignParmaChange(value) {
				
		var elementH = parseInt(attrSelectElement.item.h&&attrSelectElement.item.h.replace("px", ""));
		var elementW = parseInt(attrSelectElement.item.w&&attrSelectElement.item.w.replace("px", ""));
		
		function delectParam() {
			delete attrSelectElement.item.display;
			delete attrSelectElement.item.justifyContent;
			delete attrSelectElement.item.alignItems;	
		}
			
		function changeStatus(indexArr, value) {
			indexArr.map((item, index) => {
				if(value == item) {
					if(value >= 6 && value <= 8) {
						selectTextAlginArr[value] = selectTextAlginArr[value] == 'true' ? 'false' : 'true';
					} else {
						selectTextAlginArr[value] = 'true';
					}
				} else {
					if(value >= 6 && value <= 8) {
						selectTextAlginArr[item] = selectTextAlginArr[item];
					} else {
						selectTextAlginArr[item] = 'false';
					}
				}
			})
		}
		
		if(value <= 2) {
		   	changeStatus([0,1,2], value);
		} else if(value <= 5 && value >= 3) {
			changeStatus([3,4,5], value);
		} else if(value <= 8 && value >= 6) {	
			changeStatus([6,7,8], value);
		}
		
		switch(value) {
			case 0 :
				delectParam();
				break;
			case 1 :
				attrSelectElement.item.display = 'flex';
				attrSelectElement.item.justifyContent = attrSelectElement.item.textAlign === 'left' ? 'start' : attrSelectElement.item.textAlign === 'right' ? 'flex-end' : 'center';
				attrSelectElement.item.alignItems = 'center';
				break;
			case 2 :
				attrSelectElement.item.display = 'table-cell';
				attrSelectElement.item.verticalAlign = 'bottom';
				break;
			case 3 :
				attrSelectElement.item.textAlign = 'left';
				attrSelectElement.item.justifyContent = attrSelectElement.item.textAlign === 'left' ? 'start' : attrSelectElement.item.textAlign === 'right' ? 'flex-end' : 'center';
				break;
			case 4 :
				attrSelectElement.item.textAlign = 'center';
				attrSelectElement.item.justifyContent = attrSelectElement.item.textAlign === 'left' ? 'start' : attrSelectElement.item.textAlign === 'right' ? 'flex-end' : 'center';
				break;
			case 5 :
				attrSelectElement.item.textAlign = 'right';
				attrSelectElement.item.justifyContent = attrSelectElement.item.textAlign === 'left' ? 'start' : attrSelectElement.item.textAlign === 'right' ? 'flex-end' : 'center';
				break;
			case 6 :
				attrSelectElement.item.fontWeight = attrSelectElement.item.fontWeight == 'bold' ? '' : 'bold';
				break;
			case 7 :
				attrSelectElement.item.fontStyle = attrSelectElement.item.fontStyle == 'oblique' ? '' : 'oblique';
				break;
			case 8 :
				attrSelectElement.item.textDecoration = attrSelectElement.item.textDecoration == 'underline' ? '' : 'underline';
				break;
			default :
				break;
		}
		
		attrSelectElement.item.selectTextAlign = selectTextAlginArr.join(',');
		funcChangeAligntext(attrAligntext);
		generalValue(attrSelectElement);
	}
	
	function baseFontStyleParamonChange(value) {		
		if(value === 'normal' || value === 'oblique') {
			if(value === 'normal') {
			   	attrSelectElement.item.textDecoration = 'none';
				attrSelectElement.item.fontStyle = value;
			} else {
				attrSelectElement.item.fontStyle = value;
			}
		} else if(value === 'bold') {
			attrSelectElement.item.fontWeight = value;	  
		} else {
			attrSelectElement.item.textDecoration = value;
		}
		generalValue(attrSelectElement);
	}
		
	function baseFontFamilyParamChange(value) {
		attrSelectElement.item.fontFamily = value;
		generalValue(attrSelectElement);
	}
	
	function baseFontLineHeightParamonChange(value) {
		attrSelectElement.item.lineHeight = value;
		generalValue(attrSelectElement);
	}
	
	function baseTextMaxParamonChange(value) {
		attrSelectElement.item.textMaxLength = value;
		generalValue(attrSelectElement);
	}
	
	let pxArr = basePxFunction();
	
	let imageProps = {
		attrSelectElement,
	}
		
	function setExclusiveParam() {
		
		let gereralQrImageOrImage = (
			  <Panel header={'特有属性'} key="4">
				<div className={styles.imageBox} style={{backgroundImage : 'url(' + attrSelectElement.item.backgroundImage + ')'}}>
					{/*<ImageComponent {...imageProps} />*/}
				</div>
				<div className={styles.editElementParamLabel}>圆角</div>
				<Row>
					<Col span={12}>
						<Slider min={0} max={100} onChange={baseBorderRadiusParamonChange} value={attrSelectElement.item.borderRadius || 0} step={1} />
					</Col>
					<Col>
						<InputNumber
							style={{ marginLeft: 16 }}
							min={0}
							step={1}
							value={attrSelectElement.item.borderRadius}
							onChange={baseBorderRadiusParamonChange}
						  />
					</Col>
				</Row>
			</Panel>							
		)
		
		switch(attrSelectElement.item.type) {
			case 'text' :			
				return  <Panel header={'特有属性'} key="4">
							<Row style={{marginTop : '10px'}}>
								<div className={styles.editElementParamLabel}>文字间距</div>
								<Col>
									<InputNumber
										style={{ marginLeft: 16, width: 240, marginTop: 3 }}
										min={0}
										step={0.1}
										value={attrSelectElement.item.letterSpacing || 0}
										onChange={baseTextSpacingParamonChange}
								  	/>
								</Col>
							</Row>
							<div className={styles.exclusiveEditElementParamLabel}>背景颜色</div>
							<Row style={{marginTop : '10px'}}>
								<Col span={12}>
									<ColorSelect width='228px' height='20px' value={attrSelectElement.item.backgroundColor} onChange={baseBackgroundColorParamonChange} />
								</Col>
							</Row>
							<div className={styles.exclusiveEditElementParamLabel}>背景图片</div>
							<Row style={{marginTop : '10px'}}>
								<Col span={12}>
									<ImageBarUpdate changeImage={baseBackgroundImageParamonChange} />
								</Col>
							</Row>
							<div className={styles.exclusiveEditElementParamLabel}>字体颜色</div>
							<Row style={{marginTop : '10px'}}>
								<Col span={5}>
									<ColorSelect width='50px' height='20px' value={attrSelectElement.item.color} onChange={baseTextColorParamonChange} />
								</Col>
								<Col>
									<Select defaultValue={attrSelectElement.item.fontSize} style={{ width: 60, marginRight : '10px', marginLeft: '4px' }} onChange={baseTextPxParamonChange}>
								  		{pxArr&&pxArr.map(index => <Option key={index} value={index}>{index}</Option>)}
									</Select>
									<Select defaultValue={attrSelectElement.item.lineHeight || attrSelectElement.item.fontSize} style={{ width: 100, marginRight : '10px' }} onChange={baseFontLineHeightParamonChange}>
							  			{
											styleLinHeight&&styleLinHeight.map((item, index) => {
												return <Option key={index} value={item.value}>{item.key}</Option>
											})
										
										}
									</Select>
								</Col>
							</Row>
							{/*
								<div className={styles.exclusiveEditElementParamLabel}>字体样式</div>
								<Row style={{marginTop : '10px'}}>
									<Col span={12}>
										<Select defaultValue={attrSelectElement.item.fontStyle} style={{ width: 240, marginRight : '10px' }} onChange={baseFontStyleParamonChange}>
											{
												styleText&&styleText.map((item, index) => {
													return <Option key={index} value={item.value}>{item.key}</Option>
												})
											}
										</Select>
									</Col>
								</Row>
							*/}
							<div className={styles.exclusiveEditElementParamLabel}>字体类型</div>
							<Row style={{marginTop : '10px'}}>
								<Col span={12}>
									<Select defaultValue={attrSelectElement.item.fontFamily} style={{ width: 240, marginRight : '10px' }} onChange={baseFontFamilyParamChange}>
							  			{
											fontFamily&&fontFamily.map((item, index) => {
												return <Option key={index} value={item.value}>{item.key}</Option>
											})
										}
									</Select>
								</Col>
							</Row>
								
							<div className={styles.exclusiveEditElementParamLabel}>字体位置</div>
							<Row style={{marginTop : '10px'}}>
								<div style={{float : 'left'}}>
									{
										attrAligntext&&attrAligntext.map((item, index) => {
											let selectStyle = selectTextAlginArr[index] == 'true' ? styles.selectAlginText : styles.alignText;
											return <div key={index} className={selectStyle} style={index % 3 ? {} : {clear : 'both'}} onClick={() => textAlignParmaChange(index)}><Icon type={item.value} title={item.title}/></div>
										})
									}
								</div>
							</Row>
							<TextArea style={{marginTop : '10px'}} rows={4} onChange={baseTextParamonChange} placeholder="请输入内容" value={attrSelectElement.item.value}/>
						</Panel>
				break;
			case 'image' :
					return gereralQrImageOrImage
				break;
				case 'qrImage' :
					return gereralQrImageOrImage
				break;
			default :
				break;
		}
	}

	let styleLinHeight = [];
	
	for (let i = 0; i < 20; i++ ) {
		let fontSizeObj = {
			key : String(elementFontSize += 2) + 'px',
			value : elementFontSize,
		}
		styleLinHeight.push(fontSizeObj);
	}

	return (
		<div className="editElement">
			<Collapse accordion defaultActiveKey={attrSelectElement != undefined ? ['4'] : {}} >
				<Panel header={'基本属性'} key="1">
					<div className={styles.editElementParamLabel}>透明</div>
					<Row>
						<Col span={12}>
						  	<Slider min={0} max={1} onChange={baseOpacityParamonChange} value={attrSelectElement.item.opacity || 0} step={0.01} />
						</Col>
						<Col>
							<InputNumber
								min={0}
								max={1}
								style={{ marginLeft: 16 }}
								step={0.01}
								value={attrSelectElement.item.opacity}
								onChange={baseOpacityParamonChange}
							  />
						 </Col>
					</Row>
					<div className={styles.editElementParamLabel}>阴影</div>
					<Row>
						<Col span={12}>
					  	    <Slider defaultValue={0} onChange={baseBoxShadowParamonChange} value={attrSelectElement.item.boxShadow || 1} />
						</Col>
						<Col>
							<InputNumber
								style={{ marginLeft: 16 }}
								step={1}
								value={attrSelectElement.item.boxShadow}
								onChange={baseBoxShadowParamonChange}
							  />
						 </Col>
					</Row>
					<div className={styles.editElementParamLabel}>旋转</div>
					<Row>
						<Col span={12}>
					  	    <Slider defaultValue={0} max={360} onChange={baseRotateParamonChange} value={attrSelectElement.item.rotate || 1} />
						</Col>
						<Col>
							<InputNumber
								style={{ marginLeft: 16 }}
								step={1}
								max={360}
								value={attrSelectElement.item.rotate}
								onChange={baseRotateParamonChange}
							  />
						 </Col>
					</Row>
				</Panel>
				<Panel header={'边框属性'} key="2">
					<div className={styles.editElementParamLabel}>类型</div>
					<Row>
						<Col span={12}>
						  	 <Select defaultValue="solid" style={{ width: 255, marginTop : '3px' }} onChange={baseBorderStyleParamonChange}>
							  	<Option value="dashed">虚线</Option>
							  	<Option value="solid">实线</Option>
							  	<Option value="dotted">点缀</Option>
							</Select>
						 </Col>
					</Row>
					<div className={styles.editElementParamLabel}>粗细</div>
					<Row>
						<Col span={12}>
						  	<Slider min={0} max={100} onChange={baseBorderWidthParamonChange} value={attrSelectElement.item.borderWidth || 0} step={1} />
						</Col>
						<Col>
							<InputNumber
								style={{ marginLeft: 16 }}
								min={0}
								step={1}
								value={attrSelectElement.item.borderWidth}
								onChange={baseBorderWidthParamonChange}
							  />
						 </Col>
					</Row>
					{attrSelectElement !== undefined && attrSelectElement.item.type === 'text' ? <div className={styles.editElementParamLabel}>圆角</div> : ''}
					{attrSelectElement !== undefined && attrSelectElement.item.type === 'text' ? 
						<Row>
							<Col span={12}>
								<Slider min={0} max={100} onChange={baseBorderRadiusParamonChange} value={attrSelectElement.item.borderRadius || 0} step={1} />
							</Col>
							<Col>
								<InputNumber
									style={{ marginLeft: 16 }}
									min={0}
									step={1}
									value={attrSelectElement.item.borderRadius}
									onChange={baseBorderRadiusParamonChange}
								  />
							 </Col>
						</Row>
						: ''
					}
					<div className={styles.editElementParamLabel}>颜色</div>
					<Row>
						<Col span={12}>
							<ColorSelect width='243px' height='20px' value={attrSelectElement.item.borderColor} onChange={baseBorderColorParamonChange} />
						</Col>
					</Row>
					<div className={styles.editElementParamLabel}>上间距</div>
					<Row>
						<Col>
							<InputNumber
								style={{ marginTop: 3, width: 255 }}
								min={0}
								step={1}
								value={attrSelectElement.item.paddingTop}
								onChange={basePaddingTopSpacingParamonChange}
							  />
						 </Col>
					</Row>
					<div className={styles.editElementParamLabel}>左间距</div>
					<Row>
						<Col>
							<InputNumber
								style={{ marginTop: 3, width: 255 }}
								min={0}
								step={1}
								value={attrSelectElement.item.paddingLeft}
								onChange={basePaddingLeftSpacingParamonChange}
							  />
						 </Col>
					</Row>
					<div className={styles.editElementParamLabel}>右间距</div>
					<Row>
						<Col>
							<InputNumber
								style={{ marginTop: 3, width: 255 }}
								min={0}
								step={1}
								value={attrSelectElement.item.paddingRight}
								onChange={basePaddingRightSpacingParamonChange}
							  />
						 </Col>
					</Row>
					<div className={styles.editElementParamLabel}>下间距</div>
					<Row>
						<Col>
							<InputNumber
								style={{ marginTop: 3, width: 255 }}
								min={0}
								step={1}
								value={attrSelectElement.item.paddingBottom}
								onChange={basePaddingBottomSpacingParamonChange}
							  />
						 </Col>
					</Row>
				</Panel>								
				<Panel header={'位置属性'} key="3">
					<Row>
						<div className={styles.editElementParamLabel}>对齐</div>
						<div style={{float : 'left'}}>
							{
								attrElementLocation&&attrElementLocation.map((item, index) => {
									let selectStyle = item.selectStatus ? styles.selectAlginText : styles.alignText;
									return <div key={index} className={selectStyle} style={index % 3 ? {} : {clear : 'both'}} onClick={() => alignParmaChange(index)}><Icon type={item.value} title={item.title} /></div>
								})
							}
						</div>
					</Row>
					<div className={styles.editElementParamLabel}>宽度</div>
					<Row>
						<Col>
							<InputNumber
								style={{ marginTop: 3, width: 100, float : 'left' }}
								min={0}
								step={1}
								value={parseInt(attrSelectElement.item.h&&attrSelectElement.item.w.replace("px", "")) || 100}
								onChange={baseWidthParamonChange}
							  />
						</Col>
						<div className={styles.editElementParamLabelRight}>高度</div>
						<Col>
							<InputNumber
								style={{ marginTop: 3, width: 100 }}
								min={0}
								step={1}
								value={parseInt(attrSelectElement.item.h&&attrSelectElement.item.h.replace("px", "")) || 100}
								onChange={baseHeightParamonChange}
							  />
						</Col>
					</Row>
					<div className={styles.editElementParamLabel}>上下</div>
					<Row>
						<Col>
							<InputNumber
								style={{ marginTop: 3, width: 100, float : 'left' }}
								min={0}
								step={1}
								value={attrSelectElement.item.y || 0}
								onChange={baseTopOrBottomParamonChange}
							  />
						</Col>
						<div className={styles.editElementParamLabelRight}>左右</div>
						<Col>
							<InputNumber
								style={{ marginTop: 3, width: 100 }}
								min={0}
								step={1}
								value={attrSelectElement.item.x || 0}
								onChange={baseLeftOrRightParamonChange}
							  />
						</Col>
					</Row>
				</Panel>
				
				{setExclusiveParam()}
				
				<Panel header={'机构设置'} key="5">
				
					<Checkbox onChange={baseOrgSetParamonChange} checked={attrSelectElement.item.orgSet}>是否允许机构设置</Checkbox>
					{
						attrSelectElement.item.orgSet && attrSelectElement.item.type === 'text' ? 
							<div className={styles.setTextMax}>
								<div className={styles.editElementParamLabel}>最大字数</div>					
								<InputNumber
									style={{ marginTop: 3, width: 100, float : 'left', marginLeft : '10px' }}
									min={0}
									step={1}
									value={attrSelectElement.item.textMaxLength}
									onChange={baseTextMaxParamonChange}
								 />
							</div>
							: ''
					}
				</Panel>
				
		  	</Collapse>
		</div>
    );
}

export default TextComponent;