import React, {PropTypes} from 'react';
import ColorSelect from '../../common/color-select/ColorSelect';
import styles from './RenderLayer.less';
import {Icon, message} from 'antd';

function LayerComponent({

	//本页属性
	attrAllConfig,			//所有属性
	funcChangeElementCopy,	//复制元素
	funcChangeElementDelect,//删除元素
	funcChangeBorderColor, 	//颜色选择
	funcChangeBleedingLine, //更新出血线
	funcChangeGridLine,		//更新网格线
	funcChangeElementVisibility, //显示隐藏
	
}) {

	let behindOrFront = attrAllConfig.mainConfig.attrFrontAndBehind;

	let pageConfig = behindOrFront === 'front' ? attrAllConfig.frontPageConfig.pageConfig : attrAllConfig.behindPageConfig.pageConfig;	

	let itemConfig = behindOrFront === 'front' ? attrAllConfig.frontPageConfig.itemConfig : attrAllConfig.behindPageConfig.itemConfig;	

	let auxiliaryStyle = attrAllConfig.mainConfig.attrDirection === 'vertical' ? { marginLeft: '50px', marginTop: '50px' } : { marginLeft: '50px', marginTop: '100px' }

	//改变边框颜色
	function changeBorderColor(value) {
		if(behindOrFront === 'front') {
			attrAllConfig.frontPageConfig.pageConfig.borderColor = value;
		} else {
			attrAllConfig.behindPageConfig.pageConfig.borderColor = value;
		}
		funcChangeBorderColor(attrAllConfig);
	}
	
	//改变出血线显隐
	function changeBleedingLine() {
		attrAllConfig.mainConfig.attrShowBleedingLine = !attrAllConfig.mainConfig.attrShowBleedingLine;
		funcChangeBleedingLine(attrAllConfig);
	}
		
	//改变网格线显隐
	function changeGridLine() {
		attrAllConfig.mainConfig.attrShowGridLine = !attrAllConfig.mainConfig.attrShowGridLine;
		funcChangeGridLine(attrAllConfig);
	}
	
	//更新显隐
	function changeElementvisibility(value, index) {
		
		let newItem = itemConfig[index];
		
		newItem.item.visibility = !value;
		
		newItem.item.display = value ? 'none' : 'inline-block';
		
		newItem.item.select = false;
				
		if(behindOrFront === 'front') {
			attrAllConfig.frontPageConfig.itemConfig[index] = newItem;
		} else {
			attrAllConfig.behindPageConfig.itemConfig[index] = newItem;
		}		

		funcChangeElementVisibility(attrAllConfig);
	}
	
	//选中元素
	function changeSelectElement(index) {	
				
		let selectItem = undefined;
		itemConfig&&itemConfig.map((i, idx) => {
			if(index === idx) {
				selectItem = itemConfig[idx];
			   	itemConfig[idx].item.select = itemConfig[idx].item.visibility ? true : false;
			} else {
				itemConfig[idx].item.select = false;
			}
		})
						
		if(behindOrFront === 'front') {
			attrAllConfig.frontPageConfig.itemConfig = itemConfig;
		} else {
			attrAllConfig.behindPageConfig.itemConfig = itemConfig;
		}		

		funcChangeElementVisibility(attrAllConfig, selectItem);
	}
	
	//删除元素
	function changeDelectElement() {
		let selectIndex = undefined;
		itemConfig&&itemConfig.map((i, idx) => {			
			if(i.item.select) {	
			  	selectIndex = true;
			} 
		})
		
		if(selectIndex) {
			itemConfig&&itemConfig.map((i, idx) => {			
				if(i.item.select) {	
					itemConfig.splice(idx, 1);
				} 
			})
		} else {
			return message.error('请选择元素')
		}
		
		//从新对元素索引进行排序
		itemConfig&&itemConfig.map((item, index) => {
			itemConfig[index].index = index;
		})
						
		if(behindOrFront === 'front') {
			attrAllConfig.frontPageConfig.itemConfig = itemConfig;
		} else {
			attrAllConfig.behindPageConfig.itemConfig = itemConfig;
		}	
		
		funcChangeElementDelect(attrAllConfig);		
	}
	
	//复制元素
	function changeCopyElement() {
		let selectItem = undefined;
		let copyElement = undefined;
		let selectIndex = undefined;
		let selectNum	= 0;
		itemConfig&&itemConfig.map((i, idx) => {
			if(i.item.select) {
				selectNum++;
			  	selectIndex = true;
				
				copyElement = {
					index 	: itemConfig.length,
					item 	: JSON.parse(JSON.stringify(i.item)),
					key 	: String(new Date().getTime()),
				};
				selectItem = copyElement;
				itemConfig[idx].item.select = false;
			} 
		})
		
		if(selectIndex) {
			if(selectNum > 1) {
				return message.error('只能选择一个元素')   
			}
			
			itemConfig.push(copyElement);						
			
			if(behindOrFront === 'front') {
				attrAllConfig.frontPageConfig.itemConfig = itemConfig;
			} else {
				attrAllConfig.behindPageConfig.itemConfig = itemConfig;
			}	
		} else {
			return message.error('请选择元素')
		}
			
		funcChangeElementCopy(attrAllConfig, selectItem);
	}
			
	return (
		<div className="layerContent">
			<div className={styles.auxiliaryButton} style={auxiliaryStyle}>
				<ColorSelect width='50px' height='20px' value={pageConfig.borderColor} onChange={changeBorderColor} />
				<div className={styles.bleedingLineButton} onClick={() => changeBleedingLine()}>出血线</div>
				<div className={styles.bleedingLineButton} onClick={() => changeGridLine()}>网格线</div>
			</div>

			<div className={styles.itemHerder}>图层列表</div>
			<div className={styles.layerListBox}>
				{
					itemConfig&&itemConfig.map((item, index) => {
						let selectElementStyle = item.item.select&&item.item.visibility ? styles.itemTextSelect : styles.itemText;						
						let iconStyle = item.item.visibility ? styles.showIcon : styles.hiddenIcon;
						
						return  <div key={index} className={styles.itemBox} draggable="true">
									<div className={styles.visibilityBox} onClick={() => changeElementvisibility(item.item.visibility, index)}>
										<div className={iconStyle}></div>
									</div>
									<div className={selectElementStyle} onClick={() => changeSelectElement(index)}>
										{item.item.type == 'image' ? '图片' : item.item.type == 'qrImage' ? '二维码' : item.item.value}
									</div>
								</div>
					})
				}
			</div>
			<div className={styles.itemFooter}>
			 	<Icon type="delete" title="删除元素" className={styles.delectIcon} onClick={() => changeDelectElement()} />
				<Icon type="copy" title="复制元素" className={styles.copyIcon} onClick={() => changeCopyElement()}  />
			</div>
		</div>
	)
}

export default LayerComponent;